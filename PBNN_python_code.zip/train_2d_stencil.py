"""
train_2d_stencil.py - Sections 2 and 3 of PBNN_D.tex.

  * builds the 3726 training functions (Section 2.4.1),
  * trains the 2-patch stencils for d/dX and d/dY (Table 2),
  * tests them on [0,1]^2 with coarser grids (Tables 3 and 4).

Run: python train_2d_stencil.py
"""

import numpy as np

from common import (apply_stencil, build_2d_samples, consistency, interior,
                    normal_equations, solve_normal_equations, training_mse, unpack)

s = 2                                            # patch size
T_TEST = 1.0                                     # test domain [0,1]^2
H_TEST = (0.1, 0.05, 0.01, 0.005, 0.001, 0.0005)


def f1(X, Y):
    return np.sin(X + Y)


def f1x(X, Y):
    return np.cos(X + Y)


def f2(X, Y):
    return np.exp(np.cos(X**2 - Y**2 + X * Y))


def f2x(X, Y):
    g = X**2 - Y**2 + X * Y
    return -np.exp(np.cos(g)) * np.sin(g) * (2 * X + Y)


def f2y(X, Y):
    g = X**2 - Y**2 + X * Y
    return -np.exp(np.cos(g)) * np.sin(g) * (X - 2 * Y)


TESTS = [
    (3, "sin(X+Y)", f1, (f1x, f1x)),
    (4, "exp(cos(X^2-Y^2+XY))", f2, (f2x, f2y)),
]


def table2():
    samples, h = build_2d_samples()
    print(f"Number of training samples: {len(samples)} (paper: 3726)")
    assert len(samples) == 3726

    A, Phi = normal_equations(samples, s, h)
    print(f"h = {h:.6e}, size of A: {A.shape[0]} x {A.shape[1]}, "
          f"rank(A) = {np.linalg.matrix_rank(A)}")
    U = solve_normal_equations(A, Phi)

    print("\nTable 2 (ideal: x-der. S=0, T_x=1, T_y=0, b=0; y-der. S=0, T_x=0, T_y=1, b=0)")
    print(f"{'':8s}{'S':>14s}{'T_x':>14s}{'T_y':>14s}{'b':>14s}{'MSE':>14s}")
    for d, name in enumerate("xy"):
        S, T, b = consistency(U[:, d], s, 2)
        mse = training_mse(samples, U[:, d], s, h, d)
        print(f"{name + '-der.':8s}{S:14.6e}{T[0]:14.6e}{T[1]:14.6e}{b:14.6e}{mse:14.6e}")
    for d, name in enumerate("xy"):
        print(f"\nW^[{name}] =\n{unpack(U[:, d], s, 2)[0]}")
    return U


def tables_3_4(U):
    for tab, name, f, grads in TESTS:
        print(f"\nTable {tab}: MSE for F = {name} on [0,{T_TEST:g}]^2")
        print(f"{'h':>8s}{'MSE d/dX':>16s}{'MSE d/dY':>16s}{'order x':>10s}{'order y':>10s}")
        prev = None
        for h in H_TEST:
            N = int(round(T_TEST / h))
            x = np.arange(1, N + 1) * h
            X, Y = np.meshgrid(x, x, indexing="ij")
            F = f(X, Y)
            mse = [np.mean((interior(g(X, Y), s) - apply_stencil(F, U[:, d], s, h))**2)
                   for d, g in enumerate(grads)]
            # observed order of the RMS error: 0.5 * log(MSE ratio) / log(h ratio)
            if prev is None:
                orders = ""
            else:
                orders = "".join(f"{0.5 * np.log(pm / m) / np.log(prev[0] / h):10.3f}"
                                 for pm, m in zip(prev[1], mse))
            print(f"{h:8.4f}{mse[0]:16.8e}{mse[1]:16.8e}{orders}")
            prev = (h, mse)


if __name__ == "__main__":
    U = table2()
    tables_3_4(U)
