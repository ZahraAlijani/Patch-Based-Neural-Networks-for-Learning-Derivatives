"""
train_3d_stencil.py - Section 6 of PBNN_D.tex.

  * builds the 5346 training functions,
  * trains the cubic 2-patch stencils for d/dX, d/dY, d/dZ (Table 9).

Note: the paper's printed W^[x] differentiates along its 2nd array index
(MATLAB meshgrid convention); here axis 0 is X ("ij" indexing).

Run: python train_3d_stencil.py
"""

import numpy as np

from common import (build_3d_samples, consistency, normal_equations,
                    solve_normal_equations, training_mse, unpack)

s = 2


def main():
    samples, h = build_3d_samples()
    print(f"Number of training samples: {len(samples)} (paper: 5346)")
    assert len(samples) == 5346

    A, Phi = normal_equations(samples, s, h)
    print(f"h = {h:.6e}, size of A: {A.shape[0]} x {A.shape[1]}, "
          f"rank(A) = {np.linalg.matrix_rank(A)}")
    U = solve_normal_equations(A, Phi)

    np.set_printoptions(precision=12)
    print("\nTable 9")
    for d, name in enumerate("xyz"):
        W, b = unpack(U[:, d], s, 3)
        S, T, _ = consistency(U[:, d], s, 3)
        print(f"\n=== {name}-direction ===")
        for g in range(s):
            print(f"W[:,:,{g + 1}] =\n{W[:, :, g]}")
        print(f"b   = {b:.6e}")
        print(f"S = {S:.3e}, T = ({T[0]:.6f}, {T[1]:.6f}, {T[2]:.6f})")
        print(f"MSE = {training_mse(samples, U[:, d], s, h, d):.6e}")


if __name__ == "__main__":
    main()
