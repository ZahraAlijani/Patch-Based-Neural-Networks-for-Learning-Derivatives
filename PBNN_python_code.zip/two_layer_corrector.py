"""
two_layer_corrector.py - Section 5 of PBNN_D.tex: deepening the 2D network
with a pre-trained first layer and a second-layer corrector (Tables 7 and 8).

  layer 1:  Z1 = (1/h)(<W1, P> + b1)                       (pre-trained, Section 3)
  layer 2:  NN2 = <W2, P2> + b2 + Z1,  P2 = s-patches of sigma(Z1)

Implementation choice (not specified in the paper): the first layer is only
evaluated where its patch lies inside the grid (index >= s), so the
second-layer patches are valid for index >= 2s-1. Both models are compared
on these points.

Run: python two_layer_corrector.py
"""

import numpy as np

from common import apply_stencil, build_2d_samples, interior, patch_matrix, train_stencils

s = 2
ACTIVATIONS = {
    "identity": lambda z: z,
    "tanh": np.tanh,
    "sigmoid": lambda z: 1.0 / (1.0 + np.exp(-z)),
}


def train_corrector(samples, U1, h, sigma, d):
    """Second-layer weights from the linear system (eq:17_second_layer)."""
    nW = s**2
    A = np.zeros((nW + 1, nW + 1))
    Phi = np.zeros(nW + 1)
    for F, grads in samples:
        Z1 = apply_stencil(F, U1[:, d], s, h)
        P2 = patch_matrix(sigma(Z1), s)
        D_tilde = interior(grads[d], 2 * s - 1).ravel() - interior(Z1, s).ravel()
        A += P2.T @ P2
        Phi += P2.T @ D_tilde
    return np.linalg.lstsq(A, Phi, rcond=None)[0]


def predict(F, U1, u2, h, sigma, d):
    """(one-layer, two-layer) derivative estimates at the points with index >= 2s-1."""
    Z1 = apply_stencil(F, U1[:, d], s, h)
    one = interior(Z1, s)
    return one, one + apply_stencil(sigma(Z1), u2, s)


def mse_pair(samples, U1, u2, h, sigma, d):
    se1 = se2 = 0.0
    cnt = 0
    for F, grads in samples:
        target = interior(grads[d], 2 * s - 1)
        one, two = predict(F, U1, u2, h, sigma, d)
        se1 += np.sum((target - one)**2)
        se2 += np.sum((target - two)**2)
        cnt += target.size
    return se1 / cnt, se2 / cnt


def table7():
    samples, h = build_2d_samples(N=6, T=6e-6)      # h = 1e-6 as in the paper
    U1 = train_stencils(samples, s, h)
    print(f"Table 7: average training MSE (h = {h:g}), average of the x- and y-derivative")
    print(f"{'activation':>10s}{'one-layer':>16s}{'two-layer':>16s}"
          f"{'two-layer x':>16s}{'two-layer y':>16s}")
    correctors = {}
    for name, sigma in ACTIVATIONS.items():
        res = []
        for d in range(2):
            u2 = train_corrector(samples, U1, h, sigma, d)
            correctors[name, d] = u2
            res.append(mse_pair(samples, U1, u2, h, sigma, d))
        one = np.mean([r[0] for r in res])
        two = np.mean([r[1] for r in res])
        print(f"{name:>10s}{one:16.6e}{two:16.6e}{res[0][1]:16.6e}{res[1][1]:16.6e}")
    return U1, correctors


def table8(U1, correctors, T_end=0.5, hs=(0.1, 0.05, 0.01, 0.005, 0.001)):
    sigma = ACTIVATIONS["sigmoid"]
    u2 = correctors["sigmoid", 1]
    print(f"\nTable 8: MSE of the y-derivative of exp(cos(X^2-Y^2+XY)) on [0,{T_end:g}]^2, sigmoid")
    print(f"{'h':>8s}{'1-layer':>16s}{'2-layer':>16s}")
    for h in hs:
        N = int(round(T_end / h))
        x = np.arange(1, N + 1) * h
        X, Y = np.meshgrid(x, x, indexing="ij")
        g = X**2 - Y**2 + X * Y
        F = np.exp(np.cos(g))
        Fy = -F * np.sin(g) * (X - 2 * Y)
        target = interior(Fy, 2 * s - 1)
        one, two = predict(F, U1, u2, h, sigma, 1)
        print(f"{h:8.4f}{np.mean((target - one)**2):16.8e}{np.mean((target - two)**2):16.8e}")


if __name__ == "__main__":
    U1, correctors = table7()
    table8(U1, correctors)
