"""
solve_pde_2d.py - Section 4 of PBNN_D.tex: marching solution of first-order
PDEs with the learned 2-patch stencils.

  Example 1: u_t + u_x = 0                        (Figure 1)
  Example 2: u_t + sin(x) u_x + cos(x) u = 0      (Table 6, Figure 2)

Array axis 0 is x and axis 1 is t, so the stencil for axis 0 approximates u_x
and the one for axis 1 approximates u_t. Boundary/initial data are taken from
the exact solutions (they coincide with the conditions stated in the paper).
Figures are saved in ./results.

Run: python solve_pde_2d.py
"""

import math
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from common import build_2d_samples, march, to_uint8, train_stencils

s = 2
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")


def exact1(X, T):
    return np.sin(np.pi * (X - T))


def exact2(X, T):
    with np.errstate(invalid="ignore", divide="ignore"):
        u = np.sin(2 * np.arctan(np.exp(-T) * np.tan(X / 2))) / np.sin(X)
    return np.where(X == 0, np.exp(-T), u)          # limit x -> 0


EXAMPLE1 = dict(
    name="Example 1: u_t + u_x = 0",
    x_end=np.pi,          # as stated in the paper; probably meant to be 1
    t_end=1.0,
    G=lambda p, F, g: g[1] + g[0],
    exact=exact1,
    grids=(10, 40, 70, 100),
)

EXAMPLE2 = dict(
    name="Example 2: u_t + sin(x) u_x + cos(x) u = 0",
    x_end=1.0,
    t_end=1.0,
    G=lambda p, F, g: g[1] + math.sin(p[0]) * g[0] + math.cos(p[0]) * F,
    exact=exact2,
    grids=(10, 50, 100, 500, 1000),
)


def solve(ex, N, U):
    x = np.linspace(0, ex["x_end"], N)
    t = np.linspace(0, ex["t_end"], N)
    X, T = np.meshgrid(x, t, indexing="ij")
    F_exact = ex["exact"](X, T)
    F_num = march(ex["G"], F_exact, [U[:, 0], U[:, 1]], (x[1] - x[0], t[1] - t[0]), (x, t), s)
    return x, t, F_num, F_exact


def plot_row(axs, x, t, F_num, F_exact, N):
    ext = [x[0], x[-1], t[0], t[-1]]
    for ax, A, title in zip(axs[:2], (F_num, F_exact), ("computed", "exact")):
        ax.imshow(to_uint8(A).T, origin="lower", extent=ext, aspect="auto")
        ax.set_title(f"{title}, N = {N}")
    err = np.abs(F_num - F_exact)
    cs = axs[2].contourf(x, t, err.T, 20)
    plt.colorbar(cs, ax=axs[2])
    axs[2].set_title(f"max |error| = {err.max():.3e}")
    for ax in axs:
        ax.set_xlabel("x")
        ax.set_ylabel("t")


def run(ex, U, fig_name, fig_grids):
    print(f"\n{ex['name']}")
    print(f"{'N':>6s}{'MSE':>16s}{'max |error|':>16s}{'time [s]':>10s}")
    results = {}
    for N in ex["grids"]:
        t0 = time.time()
        x, t, F_num, F_exact = solve(ex, N, U)
        err = F_num - F_exact
        print(f"{N:6d}{np.mean(err**2):16.4e}{np.max(np.abs(err)):16.4e}{time.time() - t0:10.1f}")
        if N in fig_grids:
            results[N] = (x, t, F_num, F_exact)

    fig, axs = plt.subplots(len(fig_grids), 3, figsize=(13, 3.6 * len(fig_grids)), squeeze=False)
    for row, N in zip(axs, fig_grids):
        plot_row(row, *results[N], N)
    fig.tight_layout()
    path = os.path.join(OUT, fig_name)
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"saved {path}")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    samples, h = build_2d_samples()
    U = train_stencils(samples, s, h)
    run(EXAMPLE1, U, "Fig1_advection.png", EXAMPLE1["grids"])
    run(EXAMPLE2, U, "Fig2_variable_coefficient.png", (1000,))
