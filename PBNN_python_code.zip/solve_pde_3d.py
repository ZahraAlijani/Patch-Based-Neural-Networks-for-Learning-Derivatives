"""
solve_pde_3d.py - Section 7 of PBNN_D.tex: marching solution of
    F_t + F_y + F_z = 0,   F(0,y,z) = exp(-y^2 - z^2)
with cubic 2-patch stencils.

  * trains the stencils with the four cancellation constraints (E49)-(E52)
    and fixed central weights w_222 = (2, 0.5, 0.5),
  * shows that the unconstrained stencils of Table 9 are not usable for marching,
  * grid-refinement test (MSE table) and Figures 3 and 4.

The paper picks one member of the constrained solution family by hand
(reduced row echelon form + free parameters). Here the free parameters are
fixed by least squares instead: minimise the training loss subject to the
constraints. Array axes are (t, y, z); the domain is [0,1]^3 with equal
spacing in all directions, which the cancellation constraints require.
Figures are saved in ./results.

Run: python solve_pde_3d.py
"""

import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from common import (build_3d_samples, consistency, march, normal_equations,
                    solve_normal_equations, training_mse, unpack)

s = 2
SHARED = [(0, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 0)]   # w_111, w_121, w_112, w_211
CENTRAL = (2.0, 0.5, 0.5)                                # w_222 for t, y, z
GRIDS = (11, 21, 41, 81)
FIG_GRID = 41
FIG_TIMES = (0.146, 0.246, 0.347)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")


def G(point, F, g):
    return g[0] + g[1] + g[2]


def exact(T, Y, Z):
    return np.exp(-((Y - T)**2 + (Z - T)**2))


def constrained_stencils(A, Phi, central=CENTRAL):
    """min sum_d (u_d' A u_d - 2 u_d' Phi_d)  subject to (E49)-(E52) and w_222^[d] = central[d]."""
    n1 = s**3 + 1
    n = 3 * n1
    A_big = np.kron(np.eye(3), A)               # blkdiag(A, A, A)
    Phi_big = Phi.T.ravel()                     # [Phi_x; Phi_y; Phi_z]

    rows, rhs = [], []
    for node in SHARED:
        r = np.zeros(n)
        k = np.ravel_multi_index(node, (s,) * 3)
        r[[k, n1 + k, 2 * n1 + k]] = 1.0
        rows.append(r)
        rhs.append(0.0)
    kc = np.ravel_multi_index((s - 1,) * 3, (s,) * 3)
    for d in range(3):
        r = np.zeros(n)
        r[d * n1 + kc] = 1.0
        rows.append(r)
        rhs.append(central[d])
    C, e = np.array(rows), np.array(rhs)

    # null-space method: u = u_p + N z with C u_p = e and C N = 0
    u_p = np.linalg.lstsq(C, e, rcond=None)[0]
    _, sv, Vt = np.linalg.svd(C)
    N = Vt[np.sum(sv > 1e-12):].T
    z = np.linalg.lstsq(N.T @ A_big @ N, N.T @ (Phi_big - A_big @ u_p), rcond=None)[0]
    u = u_p + N @ z
    print(f"constraint residual: {np.max(np.abs(C @ u - e)):.2e}")
    return u.reshape(3, n1).T                   # one column per direction


def solve(N, U):
    x = np.linspace(0, 1, N)
    h = x[1] - x[0]
    T, Y, Z = np.meshgrid(x, x, x, indexing="ij")
    F_exact = exact(T, Y, Z)
    F_num = march(G, F_exact, [U[:, 0], U[:, 1], U[:, 2]], (h, h, h), (x, x, x), s)
    return x, F_num, F_exact


def figure3(x, F_num, F_exact):
    fig, axs = plt.subplots(len(FIG_TIMES), 3, figsize=(12, 3.6 * len(FIG_TIMES)), squeeze=False)
    ext = [x[0], x[-1], x[0], x[-1]]
    for row, t_target in zip(axs, FIG_TIMES):
        it = int(np.argmin(np.abs(x - t_target)))
        vmax = max(F_num[it].max(), F_exact[it].max())
        for ax, A, title in zip(row[:2], (F_num[it], F_exact[it]), ("numerical", "exact")):
            im = ax.imshow(A.T, origin="lower", extent=ext, vmin=0, vmax=vmax)
            ax.set_title(f"{title}, t = {x[it]:.3f}")
            plt.colorbar(im, ax=ax)
        im = row[2].imshow(np.abs(F_num[it] - F_exact[it]).T, origin="lower", extent=ext)
        row[2].set_title("|Num - Exact|")
        plt.colorbar(im, ax=row[2])
        for ax in row:
            ax.set_xlabel("y")
            ax.set_ylabel("z")
    fig.tight_layout()
    path = os.path.join(OUT, "Fig3_3d_advection.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"saved {path}")


def figure4(x, F_num, n_slices=6):
    Yg, Zg = np.meshgrid(x, x, indexing="ij")
    fig = plt.figure(figsize=(7, 6))
    ax = fig.add_subplot(projection="3d")
    for it in np.linspace(0, len(x) - 1, n_slices).astype(int):
        ax.contourf(Yg, Zg, F_num[it], zdir="z", offset=x[it], levels=20, cmap="viridis", alpha=0.8)
    ax.set_zlim(0, 1)
    ax.set_xlabel("y")
    ax.set_ylabel("z")
    ax.set_zlabel("t")
    ax.set_title("Stacked y-z slices of the transported Gaussian blob")
    path = os.path.join(OUT, "Fig4_stacked_slices.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"saved {path}")


def main():
    os.makedirs(OUT, exist_ok=True)
    samples, h = build_3d_samples()
    A, Phi = normal_equations(samples, s, h)

    # 1) unconstrained stencils (Table 9) used for marching
    U0 = solve_normal_equations(A, Phi)
    try:
        _, F_num, F_exact = solve(21, U0)
        print(f"Unconstrained stencils, N = 21: max |error| = {np.max(np.abs(F_num - F_exact)):.3e}")
    except (ZeroDivisionError, RuntimeError) as err:
        print(f"Unconstrained stencils, N = 21: marching failed ({err})")

    # 2) constrained stencils
    print("\nConstrained stencils (axes t, y, z):")
    U = constrained_stencils(A, Phi)
    np.set_printoptions(precision=4, suppress=True)
    for d, name in enumerate("tyz"):
        W, b = unpack(U[:, d], s, 3)
        S, T, _ = consistency(U[:, d], s, 3)
        print(f"\n=== {name}-direction ===")
        for g in range(s):
            print(f"W[:,:,{g + 1}] =\n{W[:, :, g]}")
        print(f"b = {b:.4e}, S = {S:.2e}, T = ({T[0]:.4f}, {T[1]:.4f}, {T[2]:.4f}), "
              f"training MSE = {training_mse(samples, U[:, d], s, h, d):.4e}")
    W_sum = sum(unpack(U[:, d], s, 3)[0] for d in range(3))
    print("\nCombined stencil w^[t] + w^[y] + w^[z] "
          "(upwind scheme: -1 at the three backward neighbours, 3 at the centre):")
    for g in range(s):
        print(f"[:,:,{g + 1}] =\n{W_sum[:, :, g]}")

    # 3) grid refinement and figures
    print(f"\n{'N':>6s}{'h':>10s}{'MSE':>16s}{'max |error|':>16s}{'time [s]':>10s}")
    for N in GRIDS:
        t0 = time.time()
        x, F_num, F_exact = solve(N, U)
        err = F_num - F_exact
        print(f"{N:6d}{x[1] - x[0]:10.4f}{np.mean(err**2):16.4e}"
              f"{np.max(np.abs(err)):16.4e}{time.time() - t0:10.1f}")
        if N == FIG_GRID:
            figure3(x, F_num, F_exact)
            figure4(x, F_num)


if __name__ == "__main__":
    main()
