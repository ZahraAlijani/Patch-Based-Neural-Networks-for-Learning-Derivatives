"""
common.py - shared routines for the scripts that reproduce PBNN_D.tex.

Conventions
-----------
* Arrays are indexed F[i, j] = F(X_i, Y_j) (F[i, j, k] in 3D), i.e. the first
  array index is X ("ij" indexing). Column d of a stencil matrix U therefore
  approximates the derivative along array axis d.
* A stencil is a vector u = [w_1..1, ..., w_s..s, b]: the patch weights with the
  last patch index running fastest (w_111, w_112, ... as in the paper),
  followed by the bias.
* Indices in comments are 1-based as in the paper; the code is 0-based.
* The paper calls the exponents of the training functions s,t,u; here they
  are p,q,r so that they do not clash with the patch size s.
"""

import itertools

import numpy as np

C_VALUES = (-3, -2, -1, 1, 2, 3)          # c in {±1,±2,±3}


# ---------------------------------------------------------------------------
# Training sets
# ---------------------------------------------------------------------------
def training_grid(N, T, ndim):
    """Uniform grid X_i = i*h, i = 1..N, h = T/N (Section 2.4.1)."""
    h = T / N
    x = np.arange(1, N + 1) * h
    return h, np.meshgrid(*([x] * ndim), indexing="ij")


def build_2d_samples(N=6, T=0.00005, expo=range(1, 11), cval=C_VALUES):
    """Training set of Section 2.4.1: 60+60+6 + 6*600 = 3726 functions.
    Returns (samples, h); each sample is (F, (dF/dX, dF/dY))."""
    h, (X, Y) = training_grid(N, T, 2)
    O = np.zeros_like(X)
    samples = []

    for p in expo:                                   # cX^p : 10*6 = 60
        for c in cval:
            samples.append((c * X**p, (c * p * X**(p - 1), O)))
    for q in expo:                                   # cY^q : 60
        for c in cval:
            samples.append((c * Y**q, (O, c * q * Y**(q - 1))))
    for c in cval:                                   # c : 6
        samples.append((c + O, (O, O)))

    for p in expo:                                   # 6 families, 10*10*6 = 600 each
        for q in expo:
            Xp, Yq = X**p, Y**q
            dXp, dYq = p * X**(p - 1), q * Y**(q - 1)
            for c in cval:
                g, gx, gy = c * Xp * Yq, c * dXp * Yq, c * Xp * dYq
                samples.append((g, (gx, gy)))                          # cX^pY^q
                samples.append((Xp + c * Yq, (dXp, c * dYq)))          # X^p + cY^q
                samples.append((c * Xp + Yq, (c * dXp, dYq)))          # cX^p + Y^q
                samples.append((np.sin(g), (np.cos(g) * gx, np.cos(g) * gy)))
                samples.append((np.cos(g), (-np.sin(g) * gx, -np.sin(g) * gy)))
                samples.append((np.exp(g), (np.exp(g) * gx, np.exp(g) * gy)))
    return samples, h


def build_3d_samples(N=5, T=0.00005, expo=range(1, 6), cval=C_VALUES):
    """Training set of Section 6: 30*3+6 + 7*750 = 5346 functions.
    Returns (samples, h); each sample is (F, (dF/dX, dF/dY, dF/dZ))."""
    h, (X, Y, Z) = training_grid(N, T, 3)
    O = np.zeros_like(X)
    samples = []

    for p in expo:                                   # cX^p, cY^q, cZ^r : 5*6 = 30 each
        for c in cval:
            samples.append((c * X**p, (c * p * X**(p - 1), O, O)))
    for q in expo:
        for c in cval:
            samples.append((c * Y**q, (O, c * q * Y**(q - 1), O)))
    for r in expo:
        for c in cval:
            samples.append((c * Z**r, (O, O, c * r * Z**(r - 1))))
    for c in cval:                                   # c : 6
        samples.append((c + O, (O, O, O)))

    for p in expo:                                   # 7 families, 5*5*5*6 = 750 each
        for q in expo:
            for r in expo:
                Xp, Yq, Zr = X**p, Y**q, Z**r
                dXp, dYq, dZr = p * X**(p - 1), q * Y**(q - 1), r * Z**(r - 1)
                for c in cval:
                    g = c * Xp * Yq * Zr
                    gx, gy, gz = c * dXp * Yq * Zr, c * Xp * dYq * Zr, c * Xp * Yq * dZr
                    samples.append((g, (gx, gy, gz)))                          # cX^pY^qZ^r
                    samples.append((Xp + c * Yq + Zr, (dXp, c * dYq, dZr)))    # X^p + cY^q + Z^r
                    samples.append((c * Xp + Yq + Zr, (c * dXp, dYq, dZr)))    # cX^p + Y^q + Z^r
                    samples.append((Xp + Yq + c * Zr, (dXp, dYq, c * dZr)))    # X^p + Y^q + cZ^r
                    samples.append((np.sin(g), (np.cos(g) * gx, np.cos(g) * gy, np.cos(g) * gz)))
                    samples.append((np.cos(g), (-np.sin(g) * gx, -np.sin(g) * gy, -np.sin(g) * gz)))
                    samples.append((np.exp(g), (np.exp(g) * gx, np.exp(g) * gy, np.exp(g) * gz)))
    return samples, h


# ---------------------------------------------------------------------------
# Patches
# ---------------------------------------------------------------------------
def interior(G, k):
    """Values at the points whose (1-based) index is >= k in every direction."""
    return G[(slice(k - 1, None),) * G.ndim]


def _offsets(s, ndim):
    """Patch entries in the paper's order (last index fastest)."""
    return list(itertools.product(range(s), repeat=ndim))


def _block(F, off, m):
    return F[tuple(slice(o, o + mm) for o, mm in zip(off, m))]


def patch_matrix(F, s):
    """One row per backward s-patch whose target index is >= s (no padding needed);
    columns = patch entries (last index fastest), then a 1 for the bias."""
    m = [n - s + 1 for n in F.shape]
    cols = [_block(F, off, m).ravel() for off in _offsets(s, F.ndim)]
    cols.append(np.ones(int(np.prod(m))))
    return np.column_stack(cols)


def apply_stencil(F, u, s, h=1.0):
    """(1/h) (<W, P> + b) at all targets with index >= s, without forming the patches."""
    m = [n - s + 1 for n in F.shape]
    out = np.full(m, u[-1], dtype=float)
    for col, off in enumerate(_offsets(s, F.ndim)):
        out += u[col] * _block(F, off, m)
    return out / h


# ---------------------------------------------------------------------------
# Training (normal equations, Eq. (17) and Section 6)
# ---------------------------------------------------------------------------
def normal_equations(samples, s, h):
    """Assembles A (Theta, zeta) and Phi; Phi has one column per direction."""
    ndim = samples[0][0].ndim
    nW = s**ndim
    A = np.zeros((nW + 1, nW + 1))
    Phi = np.zeros((nW + 1, ndim))
    for F, grads in samples:
        P = patch_matrix(F, s)
        A += P.T @ P
        for d, G in enumerate(grads):
            Phi[:, d] += P.T @ (h * interior(G, s).ravel())
    return A, Phi


def solve_normal_equations(A, Phi):
    """A is singular, so the solution is not unique. lstsq returns the minimum-norm
    solution; MATLAB's backslash (used in the paper) returns another member of the
    same family, so individual weights may differ while the fit is equally good."""
    return np.linalg.lstsq(A, Phi, rcond=None)[0]


def train_stencils(samples, s, h):
    A, Phi = normal_equations(samples, s, h)
    return solve_normal_equations(A, Phi)


def training_mse(samples, u, s, h, d):
    """Loss (E11)/(E12): mean of (dF/dX_d - (1/h) NN(P))^2 over all samples and points."""
    se, cnt = 0.0, 0
    for F, grads in samples:
        err = interior(grads[d], s) - apply_stencil(F, u, s, h)
        se += np.sum(err**2)
        cnt += err.size
    return se / cnt


def unpack(u, s, ndim):
    """Stencil vector -> (weight array W[alpha, beta, ...], bias b)."""
    return u[:-1].reshape((s,) * ndim), u[-1]


def consistency(u, s, ndim):
    """Consistency quantities of Section 3: S = sum of weights and
    T[d] = sum of w * offset_d (offset = index - s), so that
    (1/h) NN(P) = S F/h + sum_d T[d] dF/dX_d + b/h + O(h)."""
    W, b = unpack(u, s, ndim)
    T = []
    for d in range(ndim):
        shape = [1] * ndim
        shape[d] = s
        offset = (np.arange(s) - (s - 1)).reshape(shape)
        T.append(float(np.sum(W * offset)))
    return float(W.sum()), T, b


# ---------------------------------------------------------------------------
# Marching solver (Sections 4 and 7)
# ---------------------------------------------------------------------------
def secant(fun, x0, x1, tol=1e-12, maxit=50):
    """Scalar root of fun; exact after one step when fun is linear."""
    f0, f1 = fun(x0), fun(x1)
    for _ in range(maxit):
        if f1 == f0:
            if f1 == 0:
                return x1
            raise ZeroDivisionError("degenerate update: the PDE residual does not depend "
                                    "on the unknown (the denominator vanishes)")
        x2 = x1 - f1 * (x1 - x0) / (f1 - f0)
        if abs(x2 - x1) <= tol * (1.0 + abs(x2)):
            return x2
        x0, f0, x1, f1 = x1, f1, x2, fun(x2)
    raise RuntimeError("secant iteration did not converge")


def march(G, F_bc, stencils, hs, coords, s):
    """Solves G(point, F, [dF/dX_1, ..., dF/dX_n]) = 0 point by point.

    F_bc     : array; the slices with index 1 along each axis must hold the
               boundary data (all other entries are ignored)
    stencils : one stencil vector u per axis
    hs       : grid spacing per axis
    coords   : 1D coordinate array per axis
    Boundary patches use the replication padding of Eq. (patch_def).
    """
    ndim = F_bc.ndim
    F0 = np.zeros(F_bc.shape)
    for d in range(ndim):
        idx = [slice(None)] * ndim
        idx[d] = 0
        F0[tuple(idx)] = F_bc[tuple(idx)]
    F = np.pad(F0, [(s - 1, 0)] * ndim, mode="edge")

    W = [unpack(u, s, ndim)[0] for u in stencils]
    b = [u[-1] for u in stencils]
    wc = [w[(-1,) * ndim] for w in W]            # weight of the unknown F_ij(k)

    for idx in itertools.product(*(range(1, n) for n in F_bc.shape)):
        patch = F[tuple(slice(i, i + s) for i in idx)]   # unknown entry is still 0
        R = [np.sum(W[d] * patch) + b[d] for d in range(ndim)]
        point = tuple(coords[d][idx[d]] for d in range(ndim))

        def fun(v):
            return G(point, v, [(wc[d] * v + R[d]) / hs[d] for d in range(ndim)])

        guess = F[tuple(i + s - 2 if d == ndim - 1 else i + s - 1 for d, i in enumerate(idx))]
        F[tuple(i + s - 1 for i in idx)] = secant(fun, guess, guess + 1.0)

    return F[(slice(s - 1, None),) * ndim]


def to_uint8(A):
    """Image normalisation of Section 4: shift by the minimum, scale to [0, 255]."""
    A = A - A.min()
    mx = A.max()
    return np.uint8(np.round(255 * A / mx)) if mx > 0 else np.zeros(A.shape, np.uint8)
